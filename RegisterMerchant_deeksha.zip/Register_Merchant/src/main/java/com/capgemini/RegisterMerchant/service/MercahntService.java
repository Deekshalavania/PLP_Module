package com.capgemini.RegisterMerchant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.RegisterMerchant.bean.Merchant;
import com.capgemini.RegisterMerchant.exception.MerchantAlreadyExist;
import com.capgemini.RegisterMerchant.repo.IMerchantRepository;


@Service
public class MercahntService implements IMerchantService{

	@Autowired
	IMerchantRepository repo;
	
	@Override
	public Merchant registerMerchant(Merchant merchant) throws MerchantAlreadyExist {
		if(repo.findMerchantByMobileNo(merchant.getMobile_no()) == null)
			return repo.registerMerchant(merchant) ;
		else
			throw new MerchantAlreadyExist("Merchant Already exist with this Mobile Number");
	}

	
}
