package com.capgemini.RegisterMerchant.repo;

import com.capgemini.RegisterMerchant.bean.Merchant;
import com.capgemini.RegisterMerchant.exception.MerchantAlreadyExist;

public interface IMerchantRepository {

	Merchant registerMerchant(Merchant merchant) throws MerchantAlreadyExist;

	Merchant findMerchantByMobileNo(String mobile_no);
}
