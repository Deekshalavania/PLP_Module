package com.capgemini.RegisterMerchant.exception;

public class MerchantAlreadyExist extends Exception {

	public MerchantAlreadyExist(String msg) {
		super(msg);
	}

}
