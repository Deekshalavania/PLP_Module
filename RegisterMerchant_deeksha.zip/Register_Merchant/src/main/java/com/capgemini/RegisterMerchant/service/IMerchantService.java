package com.capgemini.RegisterMerchant.service;

import com.capgemini.RegisterMerchant.bean.Merchant;
import com.capgemini.RegisterMerchant.exception.MerchantAlreadyExist;

public interface IMerchantService {

	Merchant registerMerchant(Merchant merchant) throws MerchantAlreadyExist;
}
