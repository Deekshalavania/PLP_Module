package com.capgemini.RegisterMerchant.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.capgemini.RegisterMerchant.bean.Merchant;
import com.capgemini.RegisterMerchant.exception.MerchantAlreadyExist;
import com.capgemini.RegisterMerchant.service.IMerchantService;


@Controller
public class MerchantController {

	@Autowired
	IMerchantService service;

	
	@RequestMapping("/")
	public String hello() {
		return "/pages/registerMerchant.jsp";
	}
	

	@RequestMapping( value = "/registerMerchant")
	public String createProduct(Merchant merchant) throws MerchantAlreadyExist  {
		 service.registerMerchant(merchant);
		 return "/pages/sucess.jsp";
	}
	
}
